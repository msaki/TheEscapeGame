display.setStatusBar( display.HiddenStatusBar )

local widget = require('widget')
local composer = require('composer')

local function showScene1() -- Brings up the main menu.

   local options = {
      effect = "fade",
      time = 300
   }
   composer.gotoScene("scene1", options)

end

showScene1();






